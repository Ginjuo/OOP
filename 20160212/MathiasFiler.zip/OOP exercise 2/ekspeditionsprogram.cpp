#include <iostream>
#include <conio.h>
#include "Cursor.h"
#include "Display.h"
#include "KasseKnap.h"
#include "Nummerstander.h"




using namespace std;


int main()
{
	cout << "Tast 'n' for at tr�kke et nummer." << endl;
	cout << "Tast '1' for ny kunde ved kasse 1." << endl;
	cout << "Tast '2' for ny kunde ved kasse 2." << endl;
	cout << "Tast '3' for ny kunde ved kasse 3." << endl;
	cout << "Tast 'q' for lukke programmet.\n\n\n\n\n";
	cout << "   Kasse1    Kasse2    Kasse3" << endl;

	// erkl�ring af objekter og variable
	Nummerstander Stander1;
	Display Display1(1);
	Display Display2(2);
	Display Display3(3);
	KasseKnap Knap1(&Display1, &Stander1);
	KasseKnap Knap2(&Display2, &Stander1);
	KasseKnap Knap3(&Display3, &Stander1);

	int tast;
	do
	{
		tast = getch();

		switch (tast)
		{

		case 'n':
			Stander1.traekNummer();
			break;
		case '1':
			Knap1.tryk();
			break;
		case '2':
			Knap2.tryk();
			break;
		case '3':
			Knap3.tryk();
			break;

		}
	}
	while (tast != 'q' && tast != 'Q');
	return 0;

}