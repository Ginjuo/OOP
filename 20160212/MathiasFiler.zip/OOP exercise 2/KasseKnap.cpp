#include "KasseKnap.h"
#include "Display.h"
#include "Nummerstander.h"


KasseKnap::KasseKnap(Display * displayPointer, Nummerstander * nummerstanderPointer)
{
	displayPtr_ = displayPointer;
	nummerPtr_ = nummerstanderPointer;
}

void KasseKnap::tryk(void)
{
	int naesteNummer=nummerPtr_->getNaesteNummerIKoe();
	if (naesteNummer != -1)
	{
		displayPtr_->opdater(naesteNummer);
	}
} 