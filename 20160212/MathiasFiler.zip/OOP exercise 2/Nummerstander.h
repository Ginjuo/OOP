#pragma once
class Nummerstander
{
public:
	Nummerstander();
	void traekNummer(void);
	int getNaesteNummerIKoe(void);	
private:
	int senestTrukneNummer_ = 0;
	int senestEkspederedeNummer_ = 0;
};

