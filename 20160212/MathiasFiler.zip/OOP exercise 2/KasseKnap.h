#pragma once
#include "Display.h"
#include "Nummerstander.h"
class KasseKnap
{
public:
	KasseKnap(Display *,Nummerstander *);
	void tryk(void);
private:
	Display* displayPtr_;
	Nummerstander* nummerPtr_;
};

